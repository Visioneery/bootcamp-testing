using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace AutomatedTests
{
    [TestFixture]
    public class WebDriverTests
    {
        private IWebDriver _webDriver;

        [OneTimeSetUp] //  a method that is executed once prior to executing any of the tests in the fixture.
        public void StartChrome()
        {
            _webDriver = new ChromeDriver(".");
        }

        [Test]
        public void Should_input_name_surname_and_click_checkbox_When_opens_automation_form()
        {
            _webDriver.Url = "https://demoqa.com/automation-practice-form/";

            var firstnameTextBox = _webDriver.FindElement(By.Id("firstName"));
            firstnameTextBox.SendKeys("Name");

            var lastNameTextBox = _webDriver.FindElement(By.Id("lastName"));
            lastNameTextBox.SendKeys("Surname");

            var check = _webDriver.FindElement(By.XPath("//*[@id='genterWrapper']/div[2]/div[1]/label"));
            check.Click();

            Thread.Sleep(15000);
            Assert.Pass();
        }

        [OneTimeTearDown] // method that is executed once after executing any of the tests in the fixture.
        public void CloseTest()
        {
            _webDriver.Close();
        }
    }
}