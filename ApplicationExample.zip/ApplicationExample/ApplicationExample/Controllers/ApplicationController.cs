﻿using ApplicationExample.Objects;

namespace ApplicationExample.Controllers
{
    public class ApplicationController
    {
        public int Area;

        public void Run()
        {
            var obj = new Rectangle();
            Area = obj.GetArea(2, 2);
        }
    }
}
