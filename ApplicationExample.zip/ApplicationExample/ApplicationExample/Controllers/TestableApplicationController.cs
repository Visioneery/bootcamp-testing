﻿using ApplicationExample.Interfaces;
using ApplicationExample.Objects;

namespace ApplicationExample.Controllers
{
    public class TestableApplicationController
    {
        public int Area;

        private readonly IRectangle _rectangle;

        //public TestableApplicationController()
        //{
        //    _rectangle = new Rectangle();
        //}

        public TestableApplicationController(IRectangle rectangle) // passing interface creates an additional level of abstraction 
        {
            _rectangle = rectangle;
        } // due to that we are able to create a stub for GetArea

        public void Run()
        {
            Area = _rectangle.GetArea(2, 2);
        }

        public void RunRandom()
        {
            Area = _rectangle.GetRandomArea();
        }
    }
}
