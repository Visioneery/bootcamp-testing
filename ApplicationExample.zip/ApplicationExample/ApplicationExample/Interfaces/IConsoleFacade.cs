﻿namespace ApplicationExample.Interfaces
{
    public interface IConsoleFacade
    {
        string ReadLine();
    }
}
