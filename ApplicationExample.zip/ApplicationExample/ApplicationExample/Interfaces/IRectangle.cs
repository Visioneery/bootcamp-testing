﻿namespace ApplicationExample.Interfaces
{
    public interface IRectangle
    {
        int GetArea(int width, int height);

        int GetRandomArea();
    }
}
