﻿using System.Diagnostics.CodeAnalysis;
using ApplicationExample.Controllers;

namespace ApplicationExample
{
    [ExcludeFromCodeCoverage]
    internal class Program
    {
        private static void Main()
        {
            // var app = new TestableApplicationController();
            // app.Run();
        }
    }
}
