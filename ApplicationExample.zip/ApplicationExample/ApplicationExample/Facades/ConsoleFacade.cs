﻿using System;
using System.Diagnostics.CodeAnalysis;
using ApplicationExample.Interfaces;

namespace ApplicationExample.Facades
{
    [ExcludeFromCodeCoverage] // third parties should not be tested, its contents have already been tested at the third party development stage
    public class ConsoleFacade : IConsoleFacade
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
