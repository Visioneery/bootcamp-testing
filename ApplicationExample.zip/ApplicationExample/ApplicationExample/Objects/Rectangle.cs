﻿using System;
using ApplicationExample.Facades;
using ApplicationExample.Interfaces;

namespace ApplicationExample.Objects
{
    public class Rectangle : IRectangle
    {
        private readonly IConsoleFacade _consoleFacade;

        //public Rectangle(IConsoleFacade consoleFacade)
        //{
        //    _consoleFacade = consoleFacade;
        //}

        public Rectangle()
        {
            _consoleFacade = new ConsoleFacade();
        }


        public int GetArea(int width, int height)
        {
            if (width < 0 || height < 0)
            {
                throw new ArgumentException("Wrong input parameters");
            }

            var size = width * height;
            return size;
        }

        public int InputArea()
        {
            // tip: use _consoleFacade that declared above
            var input = Console.ReadLine();

            int.TryParse(input, out var result);

            return result;
        }

        public int GetRandomArea()
        {
            var random = new Random();
            var width = random.Next(3);
            var height = random.Next(3);
            return GetArea(width, height);
        }
    }
}
