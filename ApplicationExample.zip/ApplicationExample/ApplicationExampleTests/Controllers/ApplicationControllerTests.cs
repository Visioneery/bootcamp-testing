﻿using ApplicationExample.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationExampleTests.Controllers
{
    [TestClass]
    [TestCategory("Integration")] // integration tests
    public class ApplicationControllerTests
    {
        private ApplicationController _sut; // SUT - service/system under test

        [TestInitialize]
        public void SetUp()
        {
            _sut = new ApplicationController();
        }

        [TestMethod]
        public void Given_no_value_When_Run_Then_should_set_Area()
        {
            // Given


            // When
            _sut.Run();

            // Then
            Assert.AreEqual(4, _sut.Area);

        } // This is an integration test because it covers multiple methods
    }
}
