﻿using System.Diagnostics.CodeAnalysis;
using ApplicationExample.Controllers;
using ApplicationExample.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationExampleTests.Controllers
{
    [TestClass]
    [TestCategory("Unit")]
    public class TestableApplicationControllerTests
    {
        private TestableApplicationController _sut;

        [TestInitialize]
        public void SetUp()
        {
            //_sut = new TestableApplicationController(); // within that constructor we still create new object of Rectangle
            //                                            // so it will still call inner method

            var rectangleStub = new RectangleStub();
            _sut = new TestableApplicationController(rectangleStub); // requires object to be passed in arguments
        }

        [TestMethod]
        public void Given_GetAreaMock_When_Run_Then_should_set_Area()
        {
            // Given


            // When
            _sut.Run();

            // Then
            Assert.AreEqual(4, _sut.Area);

        }

        [TestMethod]
        public void Given__When_Run_Then_should_set_Area()
        {
            // Given


            // When
            // here you can test _sut.RunRandom(); by yourselves

            // Then
        }

        [ExcludeFromCodeCoverage]
        public class RectangleStub : IRectangle // inherits
        {
            public int GetArea(int width, int height)
            {
                return 4; // mocked method doesn't know anything about the actual implementation of the method
            }

            public int GetRandomArea()
            {
                throw new System.NotImplementedException();
            }
        }
    }
}
