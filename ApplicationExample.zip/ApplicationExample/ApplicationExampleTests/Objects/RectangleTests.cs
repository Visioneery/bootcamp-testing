﻿using System;
using System.Collections.Generic;
using ApplicationExample.Interfaces;
using ApplicationExample.Objects;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ApplicationExampleTests.Objects
{
    [TestClass]
    [TestCategory("Unit")]
    public class RectangleTests
    {
        private Rectangle _sut;

        [TestInitialize]
        public void SetUp()
        {
            _sut = new Rectangle();
        }

        [TestMethod]
        public void Given_negative_width_and_height_When_GetArea_Then_should_throw_ArgumentException() // Negative test
        {
            // Given
            const int width = -1;
            const int height = -1;

            // When
            var ex = Assert.ThrowsException<ArgumentException>(() => _sut.GetArea(width, height)); 

            // Assert.Throws returns the exception that's thrown which lets you assert on the exception.

            // Then
            Assert.AreEqual(ex.Message, "Wrong input parameters");
            // Assert.AreEqual(0, result);// why it is incorrect

        }

        [TestMethod]
        public void Given_width_and_height_When_GetArea_Then_should_return_area()
        {
            // Given
            var testClass = new Rectangle();

            // When
            var result = testClass.GetArea(2, 2);

            // Then
            Assert.AreEqual(4, result);

        }

        [TestMethod]
        public void Given_some_input_When_RequestInput_Then_return_value()
        {
            // Given

            // When
            var result = _sut.InputArea();

            // Then
            Assert.AreEqual(6, result);

        }

        [TestMethod]
        public void Given_nothing_When_BuildRandom_Then_return_value() // unstable test due to unstable logic
        {
            // Given
            var testClass = new Rectangle();

            // When
            var result = testClass.GetRandomArea(); // you can try to refactor logic and test

            // Then
            Assert.AreEqual(4, result);

        }
    }
}
